﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//Guarda con persistencia variables para el funcionamiento del juego los sonidos.
public class Singleton : MonoBehaviour {

	public static int numVueltas = 4;
    public static int secuenciasPasadas = 0;
    public static List<int> secuenciaActual;

   public static AudioClip dog = Resources.Load("FX/dog") as AudioClip;
   public static AudioClip cat = Resources.Load("FX/cat") as AudioClip;
   public static AudioClip cow = Resources.Load("FX/cow") as AudioClip;
   public static AudioClip chicken = Resources.Load("FX/chicken") as AudioClip;
}
