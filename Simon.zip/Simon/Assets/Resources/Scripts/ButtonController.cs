﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class ButtonController : MonoBehaviour {

    public Sprite[] textura;
    List<int> secuenciaJugador;
    bool secuenciaCorrecta = true;

    //Carga los sprites del simon e inicializa una lista para rellenarla con la secuencia.
    private void Start()
    {
        textura = Resources.LoadAll<Sprite>("Sprites/simonNormal");
        secuenciaJugador = new List<int>();
    }

    //Cuando el jugador pulsa un botón, se emite el sonido, se cambia el color y se comprueba si es el botón que tocaba pulsar.
    public void colorPulsado(int numColor)
    {
        if(secuenciaJugador.Count < Singleton.secuenciaActual.Count)
        {
            reproduceSonido(numColor);
            //Cambiamos la imagen del boton
            if (numColor >= 2)
            {
                GameObject.Find(numColor.ToString()).GetComponent<Image>().sprite = textura[numColor + 4];
            }
            else
            {
                GameObject.Find(numColor.ToString()).GetComponent<Image>().sprite = textura[numColor + 2];
            }
            Invoke("despintarColores", 0.5f);

            //Añado el color pulsado a la lista
            secuenciaJugador.Add(numColor);
        }

        for (int i = 0; i < secuenciaJugador.Count; i++)
        {
            if (secuenciaJugador[i] != Singleton.secuenciaActual[i])
            {
                secuenciaCorrecta = false;
                break;
            }
        }
        if (!secuenciaCorrecta)
        {
            Invoke("GameOver", 0.5f);
        }
        else if(secuenciaJugador.Count == Singleton.secuenciaActual.Count && secuenciaCorrecta)
        {
            Singleton.numVueltas++;
            Singleton.secuenciasPasadas++;
            Invoke("cambiaEscena", 1);
        }                       
    }

    //Devuelve los colores de los sprites a su tono original.
    void despintarColores()
    {
        GameObject.Find("0").GetComponent<Image>().sprite = textura[0];
        GameObject.Find("1").GetComponent<Image>().sprite = textura[1];
        GameObject.Find("2").GetComponent<Image>().sprite = textura[4];
        GameObject.Find("3").GetComponent<Image>().sprite = textura[5];             
    }

    //Reproduce el sonido correspondiente.
    private void reproduceSonido(int numColor)
    {
        switch (numColor)
        {
            case 0: AudioSource.PlayClipAtPoint(Singleton.dog, transform.position); break;
            case 1: AudioSource.PlayClipAtPoint(Singleton.cat, transform.position); break;
            case 2: AudioSource.PlayClipAtPoint(Singleton.chicken, transform.position); break;
            case 3: AudioSource.PlayClipAtPoint(Singleton.cow, transform.position); break;
        }
    }

    //Carga la escena de Game Over cuando el jugador se equivoca.
    void GameOver()
    {
        SceneManager.LoadScene("GameOver");
    }

    //Al acercar el jugador la secuencia, carga la escena que mostrará una nueva secuencia.
    void cambiaEscena()
    {
        SceneManager.LoadScene("MuestraSecuencia");
    }
}
