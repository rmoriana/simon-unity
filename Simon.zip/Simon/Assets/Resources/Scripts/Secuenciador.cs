﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Secuenciador : MonoBehaviour {

    public Sprite[] textura;
    int numSeq = 0;
    
    //Carga los sprites y llama a generar una nueva secuencia.
    void Start () {
        textura = Resources.LoadAll<Sprite>("Sprites/simonNormal");
        generaSecuencia(Singleton.numVueltas);
        Invoke("pintaBotones", 0.5f);
	}
	
    //Genera la secuencia
	void generaSecuencia(int nV)
    {
        Singleton.secuenciaActual = new List<int>();
        for (int i = 0; i < nV; i++)
        {
            Singleton.secuenciaActual.Add(Random.Range(0, 4));
        }        
    }

    //Feedback visual de cada color de la secuencia mostrados cada 0.5 segundos.
    void pintaBotones()
    {
        reproduceSonido();
        if (Singleton.secuenciaActual[numSeq] >= 2)
        {
            GameObject.Find(Singleton.secuenciaActual[numSeq].ToString()).GetComponent<SpriteRenderer>().sprite = textura[Singleton.secuenciaActual[numSeq] + 4];            
        }
        else
        {
            
            GameObject.Find(Singleton.secuenciaActual[numSeq].ToString()).GetComponent<SpriteRenderer>().sprite = textura[Singleton.secuenciaActual[numSeq] + 2];
        }
                
        numSeq++;
        if (numSeq == Singleton.secuenciaActual.Count)
        {
            Invoke("cambiaEscena",1);
        }
        else
        {            
            Invoke("despintarColores", 1);            
        }
    }

    //Despinta todos los colores marcados.
    void despintarColores()
    {
        GameObject.Find("0").GetComponent<SpriteRenderer>().sprite = textura[0];
        GameObject.Find("1").GetComponent<SpriteRenderer>().sprite = textura[1];
        GameObject.Find("2").GetComponent<SpriteRenderer>().sprite = textura[4];
        GameObject.Find("3").GetComponent<SpriteRenderer>().sprite = textura[5];
        Invoke("pintaBotones", 0.5f);
    }

    //Reproduce el sonido correspondiente.
    void reproduceSonido()
    {
        switch (Singleton.secuenciaActual[numSeq])
        {
            case 0: AudioSource.PlayClipAtPoint(Singleton.dog, transform.position); break;
            case 1: AudioSource.PlayClipAtPoint(Singleton.cat, transform.position); break;
            case 2: AudioSource.PlayClipAtPoint(Singleton.chicken, transform.position); break;
            case 3: AudioSource.PlayClipAtPoint(Singleton.cow, transform.position); break;
        }
       
    }

    //Al terminar de mostrar la secuencia, cambia la escena donde el jugador puede repetirla.
    void cambiaEscena()
    {
        SceneManager.LoadScene("TurnoJugador");
    }
	
}
