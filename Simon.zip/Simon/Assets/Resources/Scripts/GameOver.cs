﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class GameOver : MonoBehaviour {

	//Muestra un mensaje personalizado en función de los aciertos totales.
	void Start () {

        if(Singleton.secuenciasPasadas == 0)
        {
            this.GetComponent<Text>().text = "¡Lástima! No has acertado ninguna secuencia.";
        }
        else if(Singleton.secuenciasPasadas == 1)
        {
            this.GetComponent<Text>().text = "¡Has acertado " + Singleton.secuenciasPasadas.ToString() + " secuencia!";
        }
        else
        {
            this.GetComponent<Text>().text = "¡Felicidades! ¡Has acertado " + Singleton.secuenciasPasadas.ToString() + " secuencias!";
        }        
	}	
}
